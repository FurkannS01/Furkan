Merhaba! Bu proje Aktila Cengiz'in Youtube kanalı üzerindeki discord bot geliştirme günlükleri videosunda kullanılmıştır.
Lütfen kullanırken saygı çerçevesinde kullananın ve sorgulamayınız.
Bu kodların hepsi tarafımca Aktila Cengiz Tarafınca kodlanmıştır.
Sizde kullanabilirsiniz açık kaynak kodudur. 
Kullanırken bir yerde adımı ve soyadımı belirtirseniz sevinirim.
Belirtmezseniz de canınız sağolsun! :)
